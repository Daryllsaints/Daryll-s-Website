$(function(){
    var products    = ['Coke', 'Skittles', 'Paper Towel', 'Diapers', 'Shampoo', 'Soap'];
    var images      = ['<img class="img-thumbnail" src="./images/coke.png">', '<img class="img-thumbnail" src="./images/skittles.jpg">', '<img class="img-thumbnail" src="./images/towel.png">', '<img class="img-thumbnail" src="./images/diapers.jpg">', '<img class="img-thumbnail" src="./images/shampoo.jpg">', '<img class="img-thumbnail" src="./images/soap.jpg">'];  
    var prices      = ['    $1.00', '    $.50', '    $13.00', '    $9.99', '    $4.50', '    $3.99'];
    var cartCounter = [];

    //Add products to the store
    for(var i = 0; i < products.length; i++)
    {
        var string = "";

        string += '<li class="list-group-item clearfix">';
        string += images[i];
        string += products[i];
        string += prices[i];
        string += '<button id="bluebtn" class="btn btn-xs pull-right" value=' + i + '>Add to Cart</button>';
        string += '</li>';

        $('#products').append(string);

        //Set the cart counter to 0 for that this index
        cartCounter.push(0);
    }

    // add the items to the car when you click the button
    $('#products').on('click', '.btn', function(){
            var index = $(this).val();
            cartCounter[index]++;
            console.log(cartCounter);
    });

    //View cart event
    $('#viewCart').on('click', function(){
        //Clear the cart
        $('#cartContents').html('');

        //Build the cart
        for(var i = 0; i < products.length; i++)
        {
            var count = cartCounter[i];
            if(count > 0) {
                var string = "";

                string += '<li class="list-group-item clearfix">';
                string += images[i] + products[i] + prices[i];
                string += '<span class="badge badge-pill badge-primary">' + count + '</span>';
                string += '</li>';

                $('#cartContents').append(string);
            }
        }
    });


});